#pragma once

double scalarProduct (double* a, double* b, int n);